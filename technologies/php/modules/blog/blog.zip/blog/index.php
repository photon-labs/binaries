<?php
include "path.php";
header("location: public_html/blog/index.php?view=blog");
?>

