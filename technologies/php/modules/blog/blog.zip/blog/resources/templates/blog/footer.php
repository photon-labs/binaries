            </div>
            <div class="footer-space">&nbsp;</div>
            </div>
            <div style="margin:0 10%">
            <footer>
            	<div id="footer"><div class="arial12px">Powerd By<span class="arial18px-red"> Pho</span><span class="arial18px">ton &nbsp; &nbsp;</span></div></div>
            </footer>
            </div>
    </body>
</html>
