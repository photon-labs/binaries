<!-- Homepage content -->
<h2>Home Page</h2>

<h3>Tutorial Details</h3>
<ul>
<li><b>Program</b>: PHP/Projects</li>

<li><b>Version</b>: 1</li>
<li><b>Difficulty:</b> Easy</li>
<li><b>Estimated Completion Time:</b> 20 minutes</li>
</ul>
<h3>Directory Structure</h3>
<p>
	I�d say the number one thing in getting your project up and running quickly is having a solid directory structure you can reuse for multiple projects. If you are using a framework, usually it will provide a structure to use, but in this scenario we�re working on a simple site or app.

</p>