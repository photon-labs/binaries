<div id="siteControls">
	<ul class="categories">
		<li>PHP</li>
		<li>HTML</li>
		<li>CSS</li>
	</ul>
	<div class="ads">
		<!-- ads code -->
	</div>
</div>