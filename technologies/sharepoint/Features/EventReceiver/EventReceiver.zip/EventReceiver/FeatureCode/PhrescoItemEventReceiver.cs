using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;

namespace Phresco.ItemEventReceiver
{
    class PhrescoItemEventReceiver : SPItemEventReceiver
    {
        public override void ItemAdded(SPItemEventProperties properties)
        {
            if (properties.ListTitle == "Announcements")
            {
                try
                {
                    base.ItemAdded(properties);
                    SPWeb web = properties.OpenWeb();
                    SPList list = web.Lists["Announcements"];
                    SPListItem item = list.Items.Add();
                    list.Update();
                    item["Title"] = properties.ListItem.Title;
                    item.Update();
                    web.Close();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public override void ItemAdding(SPItemEventProperties properties)
        {
            base.ItemAdding(properties);
        }

        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
        }

        public override void ItemUpdating(SPItemEventProperties properties)
        {
            base.ItemUpdating(properties);
        }



    }
}
