using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
namespace Phresco.ListEventReceiver
{
    /// <summary>
    /// List Events
    /// </summary>
    public class PhrescoEventReceiver : SPListEventReceiver
    {
        /// <summary>
        /// A field was added.
        /// </summary>
        public override void FieldAdded(SPListEventProperties properties)
        {
            base.FieldAdded(properties);
        }

        /// <summary>
        /// A field is being added.
        /// </summary>
        public override void FieldAdding(SPListEventProperties properties)
        {
            base.FieldAdding(properties);
        }

        /// <summary>
        /// A field was removed.
        /// </summary>
        public override void FieldDeleted(SPListEventProperties properties)
        {
            base.FieldDeleted(properties);
        }

        /// <summary>
        /// A field is being removed.
        /// </summary>
        public override void FieldDeleting(SPListEventProperties properties)
        {
            base.FieldDeleting(properties);
        }

        /// <summary>
        /// A field was updated.
        /// </summary>
        public override void FieldUpdated(SPListEventProperties properties)
        {
            base.FieldUpdated(properties);
        }

        /// <summary>
        /// A field is being updated.
        /// </summary>
        public override void FieldUpdating(SPListEventProperties properties)
        {
            base.FieldUpdating(properties);
        }

    }
}
