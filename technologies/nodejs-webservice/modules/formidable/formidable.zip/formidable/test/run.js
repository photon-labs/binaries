#!/usr/bin/env node
require('urun')(__dirname)
