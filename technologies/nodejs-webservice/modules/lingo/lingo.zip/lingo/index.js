
module.exports = require('./lib/lingo');