
0.0.4 / 2010-11-27 
==================

  * Added `Language#name` [Pau Ramon]
  * Added Spanish inflector (needs more testing) [Pau Ramon]

0.0.3 / 2010-10-25 
==================

  * Fixed _index.js_ making lingo useless from npm

0.0.2 / 2010-09-27 
==================

  * Added `lingo.join()`
  * Added i18n support

0.0.1 / 2010-09-27 
==================

  * Initial release
