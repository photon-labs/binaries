// Copy this file to test/config.js and fill in your own credentials in order
// to run the system test suite.
module.exports = {
  host: 'localhost',
  port: 3306,
  user: 'root',
  password: 'root'
};
