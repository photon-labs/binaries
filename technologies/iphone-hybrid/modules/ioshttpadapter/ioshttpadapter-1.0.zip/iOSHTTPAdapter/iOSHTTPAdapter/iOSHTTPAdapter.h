//
//  iOSHTTPAdapter.h
//  iOSHTTPAdapter
//
//  Created by Mohammad Daud on 5/23/12.
//  Copyright (c) 2012 University of Pennsylvania. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface iOSHTTPAdapter : NSObject

@end
