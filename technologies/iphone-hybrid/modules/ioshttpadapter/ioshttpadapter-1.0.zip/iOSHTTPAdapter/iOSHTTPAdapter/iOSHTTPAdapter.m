//
//  iOSHTTPAdapter.m
//  iOSHTTPAdapter
//
//  Created by Mohammad Daud on 5/23/12.
//  Copyright (c) 2012 University of Pennsylvania. All rights reserved.
//

#import "iOSHTTPAdapter.h"

@implementation iOSHTTPAdapter

@end
