suite = new Y.Test.Suite("Y as an EventTarget");

    // dom events
    // synth events
    // selector support for dom events only

suite.add(new Y.Test.Case({
    name: "Y.on",

    "test Y.on(type, fn)": function () {
    }

}));

