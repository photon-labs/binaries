YUI.add('foo', function(Y) {
    //console.log('FOO LOADED');
}, '1.0', { requires: ['io-base'] });
