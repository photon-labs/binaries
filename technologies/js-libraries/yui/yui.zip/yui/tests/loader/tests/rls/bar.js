YUI.add('bar', function(Y) {
    //console.log('BAR LOADED');
}, '1.0', { requires: ['yql'] });
