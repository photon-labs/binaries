YUI.add('group1', function(Y) {
    //console.log('GROUP1 LOADED');
}, '1.0', { requires: ['node'] });
