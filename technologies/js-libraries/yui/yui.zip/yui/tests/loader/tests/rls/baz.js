YUI.add('baz', function(Y) {
    //console.log('BAZ LOADED');
}, '1.0', { requires: ['console'] });
