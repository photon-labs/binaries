YUI.add('bar2', function(Y) {
    //console.log('BAR 2 LOADED');
}, '1.0', { requires: ['yql', 'foo'] });
