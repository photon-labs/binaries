YUI.add('foo', function(Y) {
    Y.Foo = true;
});
