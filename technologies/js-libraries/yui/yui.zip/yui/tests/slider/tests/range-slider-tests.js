YUI.add('range-slider-tests', function(Y) {




}, '@VERSION@' ,{requires:['range-slider', 'test']});
