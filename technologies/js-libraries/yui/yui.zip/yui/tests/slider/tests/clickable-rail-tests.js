YUI.add('clickable-rail-tests', function(Y) {




}, '@VERSION@' ,{requires:['clickable-rail', 'test']});
