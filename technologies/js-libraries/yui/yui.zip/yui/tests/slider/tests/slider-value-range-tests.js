YUI.add('slider-value-range-tests', function(Y) {




}, '@VERSION@' ,{requires:['slider-value-range', 'test']});
