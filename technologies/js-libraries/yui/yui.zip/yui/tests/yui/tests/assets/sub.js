YUI.add('something1', function(Y) {
    Y.something1 = true;
});
