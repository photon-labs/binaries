// Stub file provided for C extensions that include it
