<?php

	require_once('wp-blog-header.php');
	require_once('lib/facebook.php');


	define('FB_APP_ID', '196727440363715');
	define('FB_APP_SECRET', '5906e7919b464201088166318a9303a6');

	$fb = new Facebook(array(
		'appId'  => FB_APP_ID,
		'secret' => FB_APP_SECRET,
	));

	/*

	//VERSION 1 using query_posts
	// get all post permalinks
	$published_posts = wp_count_posts()->publish;	

	$args['posts_per_page'] = $published_posts;
	$args['post_type'] = array( 'post');
	//$args['post_type'] = array( 'post', 'videos');
	query_posts( $args );

	$mq = new stdClass;
	$mqCounter = 0;
	$mqCounterPadding = strlen($published_posts);


	while ( have_posts() ) : the_post();
	
		$queryId = 'query' . str_pad($mqCounter++, $mqCounterPadding, 0, STR_PAD_LEFT);
		$link = get_permalink();
		$link = str_replace('local.makeup.com', 'stage.makeup.moxieinteractive.com', $link);

		$mq->{$queryId} = "select url,total_count,like_count,comment_count,share_count,click_count from link_stat where url='" . $link . "'";
		

    endwhile;
*/


	//VERSION 2 using get_posts
	// get all post permalinks
	$published_posts = wp_count_posts()->publish;	

	$args['posts_per_page'] = $published_posts;
	$args['post_type'] = array( 'post');
	//$args['post_type'] = array( 'post', 'videos');
	$allPosts = get_posts( $args );

	//print_r($allPosts); die();

	$mq = new stdClass;
	$mqCounter = 0;
	$mqCounterPadding = strlen($published_posts);


	foreach($allPosts as $post) :
	
		//$queryId = 'query' . str_pad($mqCounter++, $mqCounterPadding, 0, STR_PAD_LEFT);
		$queryId = $post->ID;
		$link = get_permalink($post->ID);
		$link = str_replace('local.makeup.com', 'www.makeup.com', $link);
		//$link = str_replace('local.makeup.com', 'stage.makeup.moxieinteractive.com', $link);

		$mq->{$queryId} = "select url,total_count,like_count,comment_count,share_count,click_count from link_stat where url='" . $link . "'";
		

    endforeach;


//    print_r($mq);



	$param = array(       
		'method' => 'fql.multiquery',       
		'queries' => json_encode($mq),       
		'callback' => ''
	);     
	
	//print_r($param); die();  

	$queryresults = $fb->api($param);

	print_r($queryresults); die();

	$activity = array();

	foreach($queryresults as $result)
	{
		$current = $result['fql_result_set'][0];
		$activity[$current['url']] = $current['total_count'];
	}

	arsort($activity);

	print_r($activity);










/*
	$args = array(
	    'numberposts'     => 0,
	    'offset'          => 0,
	    //'category'        => ,
	    'orderby'         => 'post_date',
	    'order'           => 'DESC',
	    //'include'         => ,
	    //'exclude'         => ,
	    //'meta_key'        => ,
	    //'meta_value'      => ,
	    'post_type'       => 'post',
	    //'post_mime_type'  => ,
	    //'post_parent'     => ,
	    'post_status'     => 'publish' 
    );

    $posts = get_posts($args);

    echo '<ul>';
    foreach($posts as $post)
    {
    	echo '<li>' . get_permalink() . "</li>\n";
    }
    echo '</ul>';

*/
   


