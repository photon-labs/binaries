<?php
	
	if(empty($_GET['action']) || $_GET['action'] != 'run')
	{
		header("Location: /");
		exit();
	}
	
	require_once('wp-blog-header.php');
	
	$output = '';
	
	$total_posts =	wp_count_posts()->publish + 
					wp_count_posts()->future + 
					wp_count_posts()->draft + 
					wp_count_posts()->pending +
					wp_count_posts()->private +
					wp_count_posts()->trash +
					wp_count_posts()->auto-draft +
					wp_count_posts()->inherit;
			
	$tags = get_tags();
	
	foreach($tags as $tag)
	{
		set_time_limit(30);
		$args['posts_per_page'] = $total_posts;
		$args['post_status'] = 'any';
		$args['tag'] = $tag->slug;		
		
		$tag_posts = get_posts( $args );
		
		if (empty($tag_posts))
		{
			$output .= $tag->slug . "\t" . 'EMPTY_TAG' . "\n";
		}
		else
		{
			foreach($tag_posts as $post)
			{
				set_time_limit(30);
				$output .= $tag->name . "\t" . $tag->slug . "\t" . $post->post_title . "\t" . get_permalink($post->ID) . "\n";
			}
		}		
	}
	
	echo $output;

